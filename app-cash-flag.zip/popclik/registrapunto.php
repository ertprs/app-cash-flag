<?php 
header('Content-Type: application/json');
include_once("../_config/conexion.php");

if ($_POST["tipousuario"]=="supervisor") {
    $respuesta = '{"exito":"NO",';
    $respuesta .= '"mensaje":"Correo registrado como usuario principal."}';
} else {
    $quer0 = 'SELECT * FROM puntosderecaudacion_usuarios where email="'.$_POST["email"].'"';
    $resul0 = mysqli_query($link, $quer0);
    if ($ro0 = mysqli_fetch_array($resul0)) {
        $query  = 'UPDATE puntosderecaudacion_usuarios SET pregunta="'.$_POST["question"].'", ';
        $query .= 'hashp="'.$_POST["hashp"].'",hashr="'.$_POST["hashr"].'" WHERE email="'.$_POST["email"].'"';
        if($result = mysqli_query($link, $query)) {
            $respuesta = '{"exito":"SI",';
            $respuesta .= '"mensaje":"Registro exitoso"}';
        } else {
            $respuesta = '{"exito":"NO",';
            $respuesta .= '"mensaje":"Falló el registro."}';
        }
    } else {
        $respuesta = '{"exito":"NO",';
        $respuesta .= '"mensaje":"Usuario no registrado."}';
    }
}

echo $respuesta;
?>
