<?php 
header('Content-Type: application/json');
include_once("../_config/conexion.php");

$respuesta = '{"exito":"SI",';
$respuesta .= '"usuarios":[';

$query  = 'SELECT * FROM puntosderecaudacion_usuarios where idpunto='.$_GET["idp"];
$first = true;
$coma = "";
if ($result = mysqli_query($link, $query)) {
    while($row = mysqli_fetch_array($result)) {
		if ($first) {
			$first = false;
			$coma = "";
		} else {
			$coma = ",";
		}
		$respuesta .= $coma.'{';
		$respuesta .= '"id":'       . $row["id"]            . ',';
		$respuesta .= '"usuario":"' . trim($row["usuario"]) . '",';
		$respuesta .= '"email":"'   . trim($row["email"])   . '",';
		$respuesta .= '"status":'   . trim($row["status"]);
		$respuesta .= '}';
    }
}

$respuesta .= ']}';

echo $respuesta;
?>
