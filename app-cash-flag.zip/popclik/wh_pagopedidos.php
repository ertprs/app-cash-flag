<?php
include_once("../_config/configShopify.php");

$url = $urlFulfillmentServices;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
curl_setopt($ch,CURLOPT_HEADER, false);

$result=curl_exec($ch);

curl_close($ch);

// echo $result;
$correos = array();
if (isset($result)) {
  $almacenes=json_decode($result,true);
  foreach ($almacenes["fulfillment_services"] as $lista => $almacen) {
    $correos[] = array( $almacen["name"] => $almacen["email"] );
  }
} else {
    $correos[] = array( 'manual' => 'soluciones2000@gmail.com' );
}


define('SHOPIFY_APP_SECRET', 'c1d069cbc028ee555014195a4e072a96dff5be25df89686ce8e0bd5e249fc45a');

function verify_webhook($data, $hmac_header) {
  $calculated_hmac = base64_encode(hash_hmac('sha256', $data, SHOPIFY_APP_SECRET, true));
  return hash_equals($hmac_header, $calculated_hmac);
}

$hmac_header = $_SERVER['HTTP_X_SHOPIFY_HMAC_SHA256'];
$data = file_get_contents('php://input');
	    $mensaje = $data;
$verified = verify_webhook($data, $hmac_header);
if ($verified) {
  $orden=json_decode($data,true);

  $operadores = array();
  $first = true;
  foreach ($orden["line_items"] as $ke0 => $linea) {
    if ($first) {
      $first = false;
      $operadores[] = $linea["fulfillment_service"];
    }
    foreach ($operadores as $key => $value) {
      if ($linea["fulfillment_service"]<>$value) {
        $operadores[] = $linea["fulfillment_service"];
      }
    }
  }
  $productos = array();
  foreach ($orden["line_items"] as $ke0 => $linea) {
    $productos[] = array(
      'operador' => $linea["fulfillment_service"],
      'producto' => $linea["title"],
      'sku'      => $linea["sku"],
      'cantidad' => $linea["fulfillable_quantity"]
    );
  }

  $despacho = array();
  foreach ($operadores as $ke0 => $valu0) {
    $prodaux = array();
    $cantidad = 0;
    foreach ($productos as $key => $value) {
      if($value["operador"]==$valu0) {
        $prodaux[] = array(
          'producto' => $value["producto"],
          'sku'      => $value["sku"],
          'cantidad' => $value["cantidad"]
        );
        $cantidad++;
      }
    }
    enviar_correo($valu0, $orden["order_number"], $cantidad, $prodaux, $correos);
  }
}

function enviar_correo($operador, $orden, $cantidad, $productos, $correos) {
  $mensaje  = 
  '<!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Recibo</title>
    <link rel="stylesheet" href="">
    <style>
      @font-face {
        font-family: recibo;
        src: url("https://www.cash-flag.com/popclik/MyriadWebPro.ttf") format("truetype");
      }
    </style>
  </head>
  <body>
    <p>Estimado '.$operador.',</p>
    <p>Por favor prepara el pedido '.$orden.'.</p>
    <p>Número total de artículos: '.$cantidad.'</p>
    <p><strong>Artículos a preparar:</strong></p>
    <table border="1">
      <thead>
        <tr>
          <th>Producto</th>
          <th>SKU</th>
          <th>Cantidad</th>
        </tr>
      </thead>
      <tbody>';
      foreach ($productos as $key => $value) {
        $mensaje .=
        '<tr>
          <td>'.$value["sku"].'</td>
          <td>'.$value["producto"].'</td>
          <td style="text-align: right;">'.$value["cantidad"].'</td>
        </tr>';
      }
      $mensaje .= 
      '</tbody>
    </table>
    <br>
    <p>¡Gracias!</p>
    <p>POPCLIK</p>
  </body>
  </html>';

  $asunto = utf8_decode('Orden de despacho - Pedido # '.$orden);

  // $cabeceras = 'Content-type: text/json';
  $cabeceras = 'Content-type: text/html; charset=utf-8';

  $correo = $correos[$operador];

	mail($correo,$asunto,$mensaje,$cabeceras);
}
?>
