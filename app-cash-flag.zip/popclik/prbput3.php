<?php
include_once("../_config/configShopify.php");

$url = $urlUnaOrden.'2341886591050/cancel.json';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url );
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
// curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($variant)); 
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
// curl_setopt($ch,CURLOPT_HEADER, false); 
$response = curl_exec($ch);
echo curl_error($ch);
echo '<pre>';
var_dump(curl_getinfo($ch));
echo '</pre>';
curl_close($ch);
print_r($response);
?>
