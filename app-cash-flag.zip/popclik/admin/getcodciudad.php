<?php
header('Access-Control-Allow-Origin: *');
$url = "http://sandbox.grupozoom.com/baaszoom/public/canguroazul/getCiudades?filtro=nacional";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url );
curl_setopt($ch, CURLOPT_POST, false);
// curl_setopt($ch, CURLOPT_POSTFIELDS, "login=".$user."&clave=".$pass);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
curl_setopt($ch,CURLOPT_HEADER, false);

$result=curl_exec($ch);

curl_close($ch);

echo $result;

/////////////////////////////////////////////////////////////////////////////////////////////////
// include_once("../../_config/conexion.php");

// $query = 'select * from zoom_ciudades';
// if ($result = mysqli_query($link, $query)) {
// 	$respuesta = '{"entidadRespuesta":[';
// 	$first = true;
// 	$coma = '';
// 	while ($row = mysqli_fetch_array($result)) {
// 		if ($first) {
// 			$first = false;
// 			$coma = '';
// 		} else {
// 			$coma = ',';
// 		}
//         $codciudad     = $row["codciudad"];
//         $nombre_ciudad = $row["nombre_ciudad"];
//         $nombre_estado = $row["nombre_estado"];
//         $respuesta .= $coma.'{"codciudad":'.$codciudad.',"nombre_ciudad":"'.$nombre_ciudad.'","nombre_estado":"'.$nombre_estado.'"}';
// 	}
// 	$respuesta .= ']}';
// }
// echo $respuesta;

?>