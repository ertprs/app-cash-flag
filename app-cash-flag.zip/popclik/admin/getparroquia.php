<?php
header('Access-Control-Allow-Origin: *');
$url = "http://sandbox.grupozoom.com/baaszoom/public/canguroazul/getParroquias?codciudad=".$_GET["codciudad"]."&codmunicipio=".$_GET["codmunicipio"];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url );
curl_setopt($ch, CURLOPT_POST, false);
// curl_setopt($ch, CURLOPT_POSTFIELDS, "login=".$user."&clave=".$pass);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
curl_setopt($ch,CURLOPT_HEADER, false);

$result=curl_exec($ch);

curl_close($ch);

echo $result;

// echo '{"codciudad": "4", "nombre_ciudad": "VALENCIA", "nombre_estado": "CARABOBO"}';

/////////////////////////////////////////////////////////////////////////////////////////////////
// include_once("../../_config/conexion.php");

// $query = 'select * from zoom_parroquias where codciudad='.$_GET["codciudad"].' and codmunicipio="'.$_GET["codmunicipio"].'"';
// if ($result = mysqli_query($link, $query)) {
// 	$respuesta = '{"entidadRespuesta":[';
// 	$first = true;
// 	$coma = '';
// 	while ($row = mysqli_fetch_array($result)) {
// 		if ($first) {
// 			$first = false;
// 			$coma = '';
// 		} else {
// 			$coma = ',';
// 		}
//         $codigo_parroquia = $row["codigo_parroquia"];
//         $nombre_parroquia = $row["nombre_parroquia"];
//         $codigo_postal    = $row["codigo_postal"];
//         $respuesta .= $coma.'{"codigo_parroquia":"'.$codigo_parroquia.'","nombre_parroquia":"'.$nombre_parroquia.'","codigo_postal":"'.$codigo_postal.'"}';
// 	}
// 	$respuesta .= ']}';
// }
// echo $respuesta;

?>