<?php
header('Content-Type: application/json');
include_once("../../_config/conexion.php");
include_once("../../_config/configShopify.php");

// Escribir el metafield con el punto de recaudación y el recibo
$url = $urlUnCustomer."2740166787146".'/metafields.json';

$variant = array('metafield' => 
    array(
        'namespace' =>  'registro',
        'key' => 'cedula',
        'value' => 'V-7132358', 
        'value_type' => 'string'
    )
);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url );
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($variant)); 
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response2 = curl_exec($ch);
echo $response2;
curl_close($ch);

?>
