<?php 
header('Content-Type: application/json');
include_once("../../_config/conexion.php");

$respuesta = '{"exito":"SI",';
$respuesta .= '"transacciones":[';

$query  = 'SELECT recaudo_transacciones.*,puntosderecaudacion.nombre,puntosderecaudacion.usuario FROM recaudo_transacciones left outer join puntosderecaudacion on recaudo_transacciones.punto=puntosderecaudacion.id ';
$query  .= 'WHERE fecha>="'.$_GET["desde"];
$query  .= '" AND fecha<="'.$_GET["hasta"].'" AND punto="'.$_GET["punto"].'" and tipo="51" AND status="Confirmada" order by orden,referencia';
$cantidad = 0;
$recaudado = 0.00;
$first = true;
$coma = "";
if ($result = mysqli_query($link, $query)) {
    while($row = mysqli_fetch_array($result)) {
		if ($first) {
			$first = false;
			$coma = "";
		} else {
			$coma = ",";
		}
		$respuesta .= $coma.'{';
		$respuesta .= '"idtransaccion":"' . $row["referencia"] . '",';
		$respuesta .= '"orden":' . $row["orden"] . ',';
		$respuesta .= '"recibo":"' . $row["referencia"] . '",';
		$respuesta .= '"punto":"' . trim($row["nombre"]).'",';
		$respuesta .= '"fecha":"' . $row["fecha"].'",';
		$respuesta .= '"usuario":"' . trim($row["usuario"]) . '",';
		$respuesta .= '"monto":' . $row["monto"];
		$respuesta .= '}';
        $cantidad++;
        $recaudado += $row["monto"];
    }
}

$respuesta .= ']}';

echo $respuesta;
?>
