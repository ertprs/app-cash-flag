<?php
header('Content-Type: application/json');
include_once("../../_config/conexion.php");

$query  = 'SELECT * FROM reportepago ';
$query .= 'WHERE tipodepositante="cliente" and ';
$query .= 'fechatransaccion>="'.$_GET["desde"].'" and fechatransaccion<="'.$_GET["hasta"].'"';
$query .= 'ORDER BY status desc, fechatransaccion, orden';
if ($result = mysqli_query($link, $query)) {
  $respuesta = '{';
  $respuesta .= '"exito":"SI",';
  $respuesta .= '"transacciones":[';
  $first = true;
  $coma = "";
  while($row = mysqli_fetch_array($result)) {
    if ($first) {
      $first = false;
      $coma = "";
    } else {
      $coma = ",";
    }
    $respuesta .= $coma.'{';
    $respuesta .= '"fecha":"'.$row["fechatransaccion"].'"'.',';
    $respuesta .= '"origen":"'.$row["origen"].'"'.',';
    $respuesta .= '"referencia":"'.$row["referencia"].'"'.',';
    $respuesta .= '"monto":'.$row["monto"].',';
    $respuesta .= '"orden":'.$row["orden"].',';
    $respuesta .= '"montoorden":'.$row["montoorden"].',';
    $respuesta .= '"status":"'.$row["status"].'"';
    $respuesta .= '}';
  }
  $respuesta .= ']';
  $respuesta .= '}';
} else {
    $respuesta = '{';
    $respuesta .= '"exito":"NO",';
    $respuesta .= '"transacciones":[';
    $respuesta .= ']';
    $respuesta .= '}';
}
echo $respuesta;
?>
