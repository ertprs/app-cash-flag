<?php 
header('Content-Type: application/json');
include_once("../../_config/conexion.php");

if ($_POST["id"]=="New") {
    $hashp = hash("sha256",$_POST["pass"]);
    $hashr = hash("sha256",$_POST["resp"]);

    $query  = 'INSERT INTO puntosderecaudacion (nombre, email, direccion, usuario, telefono, pregunta, hashp, hashr) ';
    $query .= 'VALUES ("'.$_POST["nombre"].'","'.$_POST["email"].'","'.$_POST["direccion"].'","';
    $query .= $_POST["usuario"].'","'.$_POST["telefono"].'","'.$_POST["preg"].'","'.$hashp.'","'.$hashr.'")';
    $result = mysqli_query($link, $query);

    $query  = 'SELECT * FROM puntosderecaudacion where nombre="'.$_POST["nombre"].'" ';
    $query .= 'and email="'.$_POST["email"].'" and usuario="'.$_POST["usuario"].'"';
    $result = mysqli_query($link, $query);
    if ($row = mysqli_fetch_array($result)) {
        $idpunto = $row["id"];
        $quer2  = 'INSERT INTO puntosderecaudacion_usuarios (idpunto, email, usuario, pregunta, ';
        $quer2 .= 'hashp, hashr, status) VALUES ('.$idpunto.',"'.$_POST["email"].'","'.$_POST["usuario"].'",';
        $quer2 .= '"'.$_POST["preg"].'","'.$hashp.'","'.$hashr.'",1)';
        $resul2 = mysqli_query($link, $quer2);
    }
    $respuesta = '{"exito":"SI",';
    $respuesta .= '"mensaje":"Registro exitoso"}';
} else {
    $query  = 'UPDATE puntosderecaudacion SET nombre="'.$_POST["nombre"].'", email="';
    $query .= $_POST["email"].'", direccion="'.$_POST["direccion"].'", usuario="';
    $query .= $_POST["usuario"].'", telefono="'.$_POST["telefono"].'" WHERE id='.$_POST["id"];
    $result = mysqli_query($link, $query);
    $respuesta = '{"exito":"SI",';
    $respuesta .= '"mensaje":"Registro exitoso"}';
}
echo $respuesta;
?>
