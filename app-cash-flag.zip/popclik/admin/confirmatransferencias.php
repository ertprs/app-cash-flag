<?php
header('Content-Type: application/json');
include_once("../../_config/conexion.php");
include_once("../../_config/configShopify.php");

$valores = json_decode($_POST["seleccion"], true);

$mensaje = 'Hubo error al actualizar las transacciones: ';
$errores = 0;
$coma = '';
foreach ($valores["confirmar"] as $confirmar => $transaccion) {
  $query = 'SELECT * FROM reportepago WHERE id='.$transaccion;
  $result = mysqli_query($link, $query);
  $punto = '';
  $monto = 0.00;
  $flagerror = false;
  if ($row = mysqli_fetch_array($result)) {
    $punto = $row['punto'];
    $monto = $row['monto'];
    $fechareporte = $row['fechareporte'];
    $idorden = $row['idorden'];
    $orden = $row['orden'];
    $email = $row['email'];
    $nombre = $row['nombredepositante'];

    ///////////////////////////////////////////////////////////////////////////////
    // Buscar transacción

    $url = $urlBuscarTransaccion.trim($idorden).'/transactions.json';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url );
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
    curl_setopt($ch,CURLOPT_HEADER, false);

    $result=curl_exec($ch);
    curl_close($ch);

    $ordtransaccion=json_decode($result,true);

    $parent_id = $ordtransaccion["transactions"][0]["id"];
    $amount    = $ordtransaccion["transactions"][0]["amount"];
    $montopago = ($amount>$monto) ? $monto : $amount ;
    // Fin buscar transacción

    // Enviar transacción
    $ch = curl_init($url);

    $variant = array('transaction' =>
        array(
            'currency' =>  'USD',
            'amount' => trim($montopago),
            'kind' => 'capture',
            'parent_id' => trim($parent_id)
        )
    );

    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($variant));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    if (isset($response)) {
      $trx=json_decode($response,true);
      $recibo = $trx["transaction"]["id"];
    }
    // Escribir el metafield con el punto de recaudación y el recibo
    $url = $urlOrdenMetafields.trim($idorden).'/metafields.json';

    $variant = array('metafield' => 
        array(
            'namespace' =>  'recibo_'.$recibo,
            'key' => 'punto-0',
            'value' => trim($monto), 
            'value_type' => 'string'
        )
    );

    // $variant = array('metafield' => 
    //     array(
    //         'namespace' =>  'cobro_punto',
    //         'key' => 'punto-0',
    //         'value' => $recibo, 
    //         'value_type' => 'string'
    //     )
    // );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url );
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($variant)); 
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response2 = curl_exec($ch);
    curl_close($ch);
    ///////////////////////////////////////////////////////////////////////////////

    $query = 'UPDATE reportepago SET status="Confirmado" WHERE id='.$transaccion;
    $result = mysqli_query($link, $query);
    confirmacionemail($email,$nombre,$fechareporte,$orden);
    $flagerror = false;
  } else {
    $flagerror = true;
  }
  if ($flagerror) {
    $coma = ($errores==0) ? '' : ',';
    $errores++;
    $mensaje .= $coma.$transaccion;
  }
}
foreach ($valores["anular"] as $anular => $transaccion) {
  $query = 'UPDATE reportepago SET status="Anulado" WHERE id='.$transaccion;
  $flagerror = false;
  if($result = mysqli_query($link, $query)) {
    $flagerror = false;
  } else {
    $flagerror = true;
  }
  if ($flagerror) {
    $coma = ($errores==0) ? '' : ',';
    $errores++;
    $mensaje .= $coma.$transaccion;
  }
}
if ($errores>0) {
  $respuesta = '{';
  $respuesta .= '"exito":"NO",';
  $respuesta .= '"mensaje":"' . utf8_encode($mensaje.' comuniquese con soporte técnico al +584244071820.') . '"';
  $respuesta .= '}';
} else {
  $respuesta = '{';
  $respuesta .= '"exito":"SI",';
  $respuesta .= '"mensaje":"' . utf8_encode('Proceso exitoso.') . '"';
  $respuesta .= '}';
}
echo $respuesta;



function confirmacionemail($correo,$nombre,$fechareporte,$orden) {
$fecha1 = substr($fechareporte,8,2).'/'.substr($fechareporte,5,2).'/'.substr($fechareporte,0,4);
$mensaje = 
  '<!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Recibo</title>
    <link rel="stylesheet" href="">
    <style>
      @font-face {
        font-family: recibo;
        src: url("https://app.cash-flag.com/popclik/MyriadWebPro.ttf") format("truetype");
      }
    </style>
  </head>
  <body>
    <table width="400" height="auto">
      <tbody>
        <tr>
          <td>
            <div style="padding: 10px; border: solid 12.5px gray; text-align: center;font-family: Arial; color: gray;">
              <p><img src="https://app.cash-flag.com/img/popclikhoriz.png" width="120" height="27.39" /></p>
              <p>
                <img src="https://app.cash-flag.com/img/icono-03.png" width="60" height="60.41" /><br/>
                <span style="font-size: 150%; color: #00770b;">
                  <b>¡Su pago ha sido verificado!</b>
                </span>
              </p>
              <p>Estimado, <b>'.trim($nombre).'</b></p>

              <p>Su pago reportado el día '.$fecha1.' para la orden <b style="font-size: 150%;">No. '.trim($orden).'.</b> ha sido verirficado exitosamente.</p>

              <p>Su compra está siendo procesada en nuestro almacenes y será despachada a la brevedad posible.</p>

              <p><i>¡Gracias por comprar en POPClik!</i></p>

              <p style="font-size: 80%;"><b>Si tienes alguna pregunta o comentario, contáctanos a través de <a href="mailto:info@popclik.com">info@popclik.com</a></b></p>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  </body>
  </html>';

$asunto = utf8_decode('Reporte de pago verificado.');

$cabeceras = 'Content-type: text/html; charset=utf-8'."\r\n";
$cabeceras .= 'From: '.utf8_decode('POP CLIK - Sistema de Recaudación <info@popclik.com>');

  mail($correo,$asunto,$mensaje,$cabeceras);

$a = fopen('log.html','w+');
fwrite($a,$asunto);
fwrite($a,'-');
fwrite($a,$mensaje);
}
?>
