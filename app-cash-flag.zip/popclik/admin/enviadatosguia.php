<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
include_once("../../_config/conexion.php");
include_once("../../_config/configShopify.php");

$productos = json_decode($_POST["productos"],true);

// Buscar orden para generar guía
$url = $urlUnaOrden.trim($_POST["orden_id"]).".json";
// $url = $urlUnaOrden."2153289089098.json";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url );
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
curl_setopt($ch,CURLOPT_HEADER, false);

$result=curl_exec($ch);

$aux=json_decode($result,true);
$orden = $aux["order"];

curl_close($ch);

// Extracción de los códigos de ciudad, municipio y parroquia
$cadena0 = substr($orden["shipping_address"]["address2"],15);
$codciud = substr($cadena0,0,strpos($cadena0,"."));

$cadena1 = substr($cadena0,strpos($cadena0,".")+1);
$codmunc = substr($cadena1,0,strpos($cadena1,"."));

$codparr = substr($cadena1,strpos($cadena1,".")+1);


// Cálculo de la cantidad, peso y monto de la órden
// $cantidad = 0;
// $largo = count($orden["line_items"]);
// for ($i=0; $i < $largo; $i++) { 
//   $cantidad += $orden["line_items"][$i]["quantity"];
// }

// $pesoenKg = $orden["total_weight"]/1000;
// $valorenDolares = $orden["total_price"]*78000;
$cantidad = $_POST["cantidad"];
$pesoenKg = $_POST["pesoengr"]/1000;
$valorenDolares = $_POST["monto"]*78000; //OJOJOJOJOJOJO Buscar este valor en una tabla

$idcliente = $orden["customer"]["id"];
$zip = $orden["shipping_address"]["zip"];
$nombrecliente = $orden["shipping_address"]["first_name"]." ".$orden["shipping_address"]["last_name"];
$phone = $orden["shipping_address"]["phone"];
$celular = $orden["customer"]["phone"];
$address = $orden["shipping_address"]["address1"];
$numorden = $orden["order_number"];
$fechaorden = substr($orden["created_at"],0,10);

$prefijos = array('414','424','416','426','412');
$prefijoValido = 0;
foreach ($prefijos as $key) {
    $prefijoValido += substr_count($celular, $key, 0, 7);
}
$celular = ($prefijoValido>0) ? $celular : '+584141111111' ;

// Generar token
$url = "http://sandbox.grupozoom.com/baaszoom/public/guiaelectronica/generarToken";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url );
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, "login=".$user_zoom."&clave=".$pass_zoom);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
curl_setopt($ch,CURLOPT_HEADER, false);

$result=curl_exec($ch);
$aux=json_decode($result,true);
$token = $aux["entidadRespuesta"][0]["token"];

curl_close($ch);


// Genera certificado
$url = "http://sandbox.grupozoom.com/baaszoom/public/guiaelectronica/zoomCert";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url );
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, "login=".$user_zoom."&password=".$pass_zoom."&token=".$token."&frase_privada=".$priv_zoom);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
curl_setopt($ch,CURLOPT_HEADER, false);

$result=curl_exec($ch);
$aux=json_decode($result,true);
$certificado = $aux["entidadRespuesta"][0]["certificado"];

curl_close($ch);


// Genera codigo oficina destino
$url = "http://sandbox.grupozoom.com/baaszoom/public/canguroazul/getOficinasGE?codigo_ciudad_destino=".$codciud;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url );
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
curl_setopt($ch,CURLOPT_HEADER, false);

$result=curl_exec($ch);
$aux=json_decode($result,true);
$codoficinadestino = $aux["entidadRespuesta"][0]["codoficina"];

curl_close($ch);


// Buscar estado de la ciudad de destino
$estado = "";
$url = "http://sandbox.grupozoom.com/baaszoom/public/canguroazul/getCiudades?filtro=nacional";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url );
curl_setopt($ch, CURLOPT_POST, false);
// curl_setopt($ch, CURLOPT_POSTFIELDS, "login=".$user."&clave=".$pass);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
curl_setopt($ch,CURLOPT_HEADER, false);

$result=curl_exec($ch);
$aux=json_decode($result,true);
foreach ($aux["entidadRespuesta"] as $key => $value) {
    if ($value["codciudad"]==$codciud) {
        $estado = $value["nombre_estado"];
    }    
}
curl_close($ch);


// Buscar cédula o rif del cliente
$url = $urlUnCustomer.trim($idcliente)."/metafields.json";
// $url = $urlUnaOrden."2153289089098.json";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url );
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
curl_setopt($ch,CURLOPT_HEADER, false);

$result=curl_exec($ch);
if (isset($result)) {
    $aux=json_decode($result,true);
    $metafields=$aux["metafields"];
    $cedularif = "V-1234567";
    foreach ($metafields as $lista => $orden) {
        if ($orden["key"]=="cedula") {
            $aux = substr($orden["value"],0,1).'-'.substr($orden["value"],2,100);
            $cedularif = (isset($orden["value"])) ? $aux : "V-1234567";
        }
    }
}
curl_close($ch);

// Genera guía
$campos =  "login=".$user_zoom;
$campos .= "&clave=".$pass_zoom;
$campos .= "&certificado=".$certificado;
$campos .= "&codservicio="."96"; // Codigo de servicio de envío nacional 10KG
$campos .= "&consignacion="."0"; // Default, solo aplica para envíos prepagados, el "1" es consignación
$campos .= "&remitente="."POP CLIK";
$campos .= "&contacto_remitente="."POP CLIK";
$campos .= "&tiporifcirem="."J-";
$campos .= "&cirifrem="."40242441-8";
$campos .= "&codciudadrem="."4"; // "4" es Valencia
$campos .= "&codmunicipiorem="."814"; // "814" es Valencia
$campos .= "&codparroquiarem="."81407"; // "81407" es San José
$campos .= "&zona_postal_remitente="."2001"; // Valencia
$campos .= "&codcelurem="."0424";
$campos .= "&celularrem="."4071820";
$campos .= "&telefono_remitente="."02418427724";
$campos .= "&direccion_remitente="."Paseo Cabriales, Torre Movilnet";
$campos .= "&inmueble_remitente="."mezzanina local 2-3";
$campos .= "&retira_oficina="."0"; // Por default no se aceptará retiro en oficina
$campos .= "&codciudaddes=".$codciud;
$campos .= "&codmunicipiodes=".$codmunc;
$campos .= "&codparroquiades=".$codparr;
$campos .= "&zona_postal_destino=".$zip;

$campos .= "&estadodes=".$estado;

$campos .= "&codoficinades=".$codoficinadestino;
$campos .= "&destinatario=".$nombrecliente;
$campos .= "&contacto_destino=".$nombrecliente;

$campos .= "&tiporifcidest=".substr($cedularif,0,2);
$campos .= "&cirif_destinatario=".substr($cedularif,2,100);

$campos .= "&codceludest="."0".substr($celular,3,3);;
$campos .= "&celular=".substr($celular,6,100);

$campos .= "&telefono_destino=".$phone;
$campos .= "&direccion_destino=".$address;
$campos .= "&inmueble_destino=".$address;
// $campos .= "&siglas_casillero=".BRM
$campos .= "&descripcion_contenido="."MERCANCIA";
$campos .= "&referencia="."Orden No. ".$numorden;
$campos .= "&numero_piezas=".$cantidad;
$campos .= "&peso_bruto=".$pesoenKg;
$campos .= "&tipo_envio="."M";   // "M" para mercancía
$campos .= "&valor_declarado=".$valorenDolares;
$campos .= "&seguro="."1";    // "1" para seguro
$campos .= "&valor_mercancia=".$valorenDolares;
$campos .= "&modalidad_cod="."1";   // Default
// $campos .= "&codoficinaori="."136"; // Principal Valencia

// echo $campos;
$url = "http://sandbox.grupozoom.com/baaszoom/public/guiaelectronica/createShipment";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, false);
curl_setopt($ch, CURLOPT_POSTFIELDS, $campos);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
curl_setopt($ch,CURLOPT_HEADER, false);

$result=curl_exec($ch);
$aux=json_decode($result,true);
$numguia = 0;
$numguia = $aux["entidadRespuesta"][0]["numguia"];

curl_close($ch);

if ($numguia<>0) {
    // Respuesta
    $respuesta = '{"exito":"SI","mensaje":"Registro exitoso, número de guía: '.$numguia.'","numguia": '.$numguia.', "response":'.$result.'}';

    // Buscar orden para generar guía
    $url = $urlUnaOrden.trim($_POST["orden_id"])."/fulfillments.json";
    // $url = $urlUnaOrden."2153289089098.json";

    $items = array();
    foreach ($productos["enviar"] as $key => $value) {
        $items[] = array('id' => $value["id"], 'quantity' => $value["cantidad"] );
    }

    $variant = array('fulfillment' =>
        array(
            'location_id' =>  33406189642,  // Este número corresponde al warehouse
            'tracking_number' => $numguia,
            'tracking_urls' => array('https://www.zoomenvios.com/zoomtrack/viaweb.html'),
            'line_items' => $items,
            'notify_customer' => true,
            'tracking_company' => 'Zoom Envíos'
        )
    );

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($variant));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $result=curl_exec($ch);

    $status = curl_error($ch);
    $statu2 = curl_errno($ch);

    curl_close($ch);

    // Grabar fecha y hora de despacho
    $url = $urlOrdenMetafields.trim($_POST["orden_id"]).'/metafields.json';

    $variant = array('metafield' => 
        array(
            'namespace' =>  'fecha_hora_despacho',
            'key' => 'fecha-hora-operador',
            'value' => date('Y-m-d / H:i:s').' / '.'1', 
            'value_type' => 'string'
        )
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url );
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($variant)); 
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response2 = curl_exec($ch);
    curl_close($ch);
} else {
    // Respuesta
    $first = true;
    $coma = "";
    $msj = '';
    $aerrores = array();
    foreach ($aux["entidadRespuesta"] as $key => $value) {
        if ($first) {
            $first = false;
        } else {
            $coma = ",";
        }
        $msj .= $coma.'"'.$value.'"';
        $aerrores[] = $value;
    }

    $query =  'INSERT INTO ordenes_errores (orden_id, orden, fecha, nombre_cliente, errores) VALUES ';
    $query .= '('.$_POST["orden_id"].','.$numorden.',"'.$fechaorden.'","'.utf8_encode($nombrecliente).'",'.$msj.')';
    $result = mysqli_query($link, $query);

    $respuesta = '{"exito":"NO","mensaje":"No se generó la guía, consulte los datos del cliente.","numguia": 0, "response":['.$msj.']}';
    $correo = 'soluciones2000@gmail.com';
    notificacioncliente($nombrecliente, $numorden, $aerrores, $correo);
}

// Enviar respuesta
echo $respuesta;


function notificacioncliente($nombrecliente, $orden, $errores, $correo) {
$mensaje .= 
  '<!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Recibo</title>
    <link rel="stylesheet" href="">
    <style>
      @font-face {
        font-family: recibo;
        src: url("https://www.cash-flag.com/popclik/MyriadWebPro.ttf") format("truetype");
      }
    </style>
  </head>
  <body>
    <p><img src="https://www.cash-flag.com/img/popclikhoriz.png" width="120" height="27.39" /></p>

    <p>Estimado '.trim($nombrecliente).',</p>

    <p>La orden No. '.trim($orden).' no pudo ser despachada por presentar los siguientes errores en los datos básicos:</p>

    <ul>';
    for ($i=0; $i < count($errores); $i++) { 
        $mensaje .= '<li>'.$errores[$i].'</li>';
    }
    $mensaje .= '</ul>

    <p>Por favor ingresa a la tienda en línea y modifica los datos de tu cuenta para corregir estos errores y proceder nuevamente con el despacho.</p>

    <p><i>¡Gracias por comprar en POPClik!</i></p>
    
    <p style="font-size: 80%;"><b>Ingresa a tu cuenta de usuario en <a href="http://www.popclik.com">www.popclik.com</a></b></p>

    <p style="font-size: 80%;"><b>Si tienes alguna pregunta o comentario, contáctanos a través de <a href="mailto:info@popclik.com">info@popclik.com</a></b></p>
  </body>
  </html>';

$asunto = 'Se requiere una acción en la orden No. '.$orden.'.';
// $cabeceras = 'Content-type: text/html'.'\r\n';

// $cabeceras = 'Content-type: text/html; charset=utf-8'."\r\n";
// $cabeceras .= 'From: '.utf8_decode('POP CLIK - Sistema de Guías electrónicas <'.trim($emailpunto).'>');
$cabeceras = 'Content-type: text/html; charset=utf-8';

// if (strpos($_SERVER["SERVER_NAME"],'localhost')===FALSE) {              
  // mail($correo,$asunto,$mensaje,$cabeceras,'-f '.trim($emailpunto));
  mail($correo,$asunto,$mensaje,$cabeceras);
// }

$a = fopen('log.html','w+');
fwrite($a,$asunto);
fwrite($a,'-');
fwrite($a,$mensaje);
}

?>
