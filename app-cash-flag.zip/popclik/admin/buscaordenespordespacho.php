<?php
include_once("../../_config/conexion.php");
include_once("../../_config/configShopify.php");

$respuesta = '';

$query  = 'SELECT * FROM ordenes_errores';
$primeraparte = false;
if ($qresult = mysqli_query($link, $query)) {
    $primeraparte = true;
    $respuesta = '{"ordenes":[';
    $first = true;
    $coma = "";
    while($row = mysqli_fetch_array($qresult)) {
        if ($first) {
            $first = false;
            $coma = "";
        } else {
            $coma = ",";
        }
        $respuesta .= $coma.'{';
        $respuesta .= '"id":'.$row["orden_id"].',';
        $respuesta .= '"orden":'. $row["orden"] .',';
        $respuesta .= '"fecha":"'.$row["fecha"].'",';
        $respuesta .= '"nombre_cliente":"' . $row["nombre_cliente"] . '",';
        $respuesta .= '"errores":' . $row["errores"] . ',';
        $respuesta .= '"productos":[],';
        $respuesta .= '"status_despacho":"Con errores"';
        $respuesta .= '}';
    }
}

$url = $urlOrdenesPagadas;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
curl_setopt($ch,CURLOPT_HEADER, false);

$result=curl_exec($ch);

curl_close($ch);

// echo $result;

if (isset($result)) {
    if ($primeraparte) {
        $respuesta .= ',';
    } else {
        $respuesta = '{"ordenes":[';
    }
    $ordenes=json_decode($result,true);
    $first = true;
    $coma = "";
    foreach ($ordenes["orders"] as $lista => $orden) {
        if($orden["fulfillment_status"]!="fulfilled"){
            if ($first) {
                $first = false;
                $coma = "";
            } else {
                $coma = ",";
            }
            // Datos generales de la orden
            $respuesta .= $coma.'{';
            $respuesta .= '"id":'.$orden["id"].',';
            $respuesta .= '"orden":'. $orden["order_number"] .',';
            $respuesta .= '"fecha":"'.$orden["created_at"].'",';
            $respuesta .= '"nombre_cliente":"' . trim($orden["customer"]["first_name"])." ".trim($orden["customer"]["last_name"]) . '",';
            $respuesta .= '"errores":[],';
            $respuesta .= '"productos":[';
            $coma = '';
            $first = true;
            foreach ($orden["line_items"] as $items => $producto) {
                if ($first) {
                    $first = false;
                    $coma = '';
                } else {
                    $coma = ',';
                }
                $respuesta .= $coma.'{';
                $respuesta .= '"descripcion":"'. $producto["name"] .'",';
                $respuesta .= '"cantidad":'. $producto["fulfillable_quantity"] .',';
                $respuesta .= '"almacen":"'. $producto["fulfillment_service"] .'"}';
            }
            $respuesta .= '],';

            if ($orden["fulfillment_status"]=="") {
                $status = "Pendiente";
            } else {
                $status = "Parcialmente despachada";
            }            
            $respuesta .= '"status_despacho":"' . $status . '"';
            $respuesta .= '}';
        }
    }
}
$respuesta .= ']';
$respuesta .= '}';
echo $respuesta;
?>
