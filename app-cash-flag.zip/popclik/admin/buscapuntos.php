<?php 
header('Content-Type: application/json');
include_once("../../_config/conexion.php");

$respuesta = '{"exito":"SI",';
$respuesta .= '"puntos":[';

$query  = 'SELECT * FROM puntosderecaudacion';
$first = true;
$coma = "";
if ($result = mysqli_query($link, $query)) {
    while($row = mysqli_fetch_array($result)) {
		if ($first) {
			$first = false;
			$coma = "";
		} else {
			$coma = ",";
		}
		$respuesta .= $coma.'{';
		$respuesta .= '"id":'         . $row["id"]              . ',';
		$respuesta .= '"nombre":"'    . trim($row["nombre"])    . '",';
		$respuesta .= '"direccion":"' . trim($row["direccion"]) . '",';
		$respuesta .= '"telefono":"'  . trim($row["telefono"])  . '",';
		$respuesta .= '"email":"'     . trim($row["email"])     . '",';
		$respuesta .= '"usuario":"'   . trim($row["usuario"])   . '"';
		$respuesta .= '}';
    }
}

$respuesta .= ']}';

echo $respuesta;
?>
