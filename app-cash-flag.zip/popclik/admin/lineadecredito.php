<?php
header('Content-Type: application/json');
include_once("../../_config/conexion.php");

$ultimopago = date("Y-m-d");
$diasdecredito = $_POST["diasdecredito"];

// proximo pago (10 días)
$proximopago = strtotime('+'.$diasdecredito.' days', strtotime ($ultimopago));
$proximopago = date('Y-m-d', $proximopago);

$query = 'UPDATE puntosderecaudacion SET lineadecredito='.$_POST["lineadecredito"].', diasdecredito='.$_POST["diasdecredito"].', proximopago="'.$proximopago.'" WHERE id='.$_POST["punto"];
if ($result = mysqli_query($link, $query)){
	$respuesta = '{';
	$respuesta .= '"exito":"SI",';
	$respuesta .= '"mensaje":"' . utf8_encode('Registro exitoso.') . '"';
	$respuesta .= '}';
} else {
	$respuesta = '{';
	$respuesta .= '"exito":"NO",';
	$respuesta .= '"mensaje":"' . utf8_encode('No se realizó correctamente la operación, comuniquese con soporte técnico.') . '"';
	$respuesta .= '}';
}
echo $respuesta;
?>
