<?php
include_once("../../_config/configShopify.php");

$url = $urlOrdenesPagadas;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url );
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
curl_setopt($ch,CURLOPT_HEADER, false);

$result=curl_exec($ch);

curl_close($ch);

// echo $result;

$respuesta = '{"exito":"NO",';
$respuesta .= '"orden":{';
$respuesta .= '"id":"",';
$respuesta .= '"nombres":"",';
$respuesta .= '"telefono":"",';
$respuesta .= '"direccion":"",';
$respuesta .= '"zonapostal":"",';
$respuesta .= '"ciudad":"",';
$respuesta .= '"estado":"",';
$respuesta .= '"productos":[{"id":"","nombre":"","cantidad":0,"precio":0.00,"imagen":"","gramos":0,"upc":""}]}';
$respuesta .= '}';

if (isset($result)) {
    $ordenes=json_decode($result,true);
    foreach ($ordenes["orders"] as $lista => $orden) {
        if ($_GET["orden"]==$orden["order_number"]) {
            $respuesta = '{';
                $respuesta .= '"exito":"SI",';
                $respuesta .= '"orden":{';
                    $respuesta .= '"id":"'.$orden["id"].'",';
                    $respuesta .= '"nombres":"' . trim($orden["customer"]["first_name"]).' '.trim($orden["customer"]["last_name"]) . '",';
                    $respuesta .= '"telefono":"' . trim($orden["customer"]["phone"]) . '",';
                    $respuesta .= '"direccion":"' . trim($orden["shipping_address"]["address1"]).' '.trim($orden["shipping_address"]["address2"]). '",';
                    $respuesta .= '"zonapostal":"' . trim($orden["shipping_address"]["zip"]) . '",';
                    $respuesta .= '"ciudad":"' . trim($orden["shipping_address"]["city"]) . '",';
                    $respuesta .= '"estado":"' . trim($orden["shipping_address"]["province"]) . '",';
                    $respuesta .= '"productos":[';
                        $largo = count($orden["line_items"]);
                        $coma = '';
                        $first = true;
                        for ($i=0; $i < $largo; $i++) {
                            if ($first) {
                                $first = false;
                                $coma = '';
                             } else {
                                $coma = ',';
                             }
                              
                            $respuesta .= $coma.'{';
                                // $respuesta .= '"id":"' . $orden["line_items"][$i]["product_id"] . '",';
                                $respuesta .= '"id":"' . $orden["line_items"][$i]["id"] . '",';
                                $respuesta .= '"nombre":"' . $orden["line_items"][$i]["name"] . '",';
                                $respuesta .= '"cantidad":' . $orden["line_items"][$i]["fulfillable_quantity"] . ',';
                                $respuesta .= '"precio":' . $orden["line_items"][$i]["price"] . ',';

                                $peso = $orden["line_items"][$i]["grams"];
                                // Busqueda de imagen
                                $url2 = $urlUnProducto.$orden["line_items"][$i]["product_id"].'.json';
                                $ch2 = curl_init();
                                curl_setopt($ch2, CURLOPT_URL,$url2 );
                                curl_setopt($ch2,CURLOPT_RETURNTRANSFER,true);// set optional params
                                curl_setopt($ch2,CURLOPT_HEADER, false);
                                $result2=curl_exec($ch2);
                                curl_close($ch2);

                                if (isset($result2)) {
                                    $productos=json_decode($result2,true);
                                    if (!isset($productos["errors"])) {
                                        $respuesta .= '"imagen":"' . $productos["product"]["image"]["src"] . '",';
                                        $respuesta .= '"gramos":' . $productos["product"]["variants"][0]["grams"].',';
                                        $respuesta .= '"upc":"' . $productos["product"]["variants"][0]["barcode"].'"';
                                    } else {
                                        $respuesta .= '"imagen":"","gramos":'.$peso.',"upc":""';
                                    }                                
                                } else {
                                    $respuesta .= '"imagen":"","gramos":'.$peso.',"upc":""';
                                }

                            $respuesta .= '}';
                        }
                    $respuesta .= ']';
                $respuesta .= '}';
            $respuesta .= '}';
        }
    }
}

echo $respuesta;
?>
