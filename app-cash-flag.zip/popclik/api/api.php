<?php
include_once("../../_config/configShopify.php");

$url = $urlOrdenes;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
curl_setopt($ch,CURLOPT_HEADER, false);

$result=curl_exec($ch);

curl_close($ch);

$respuesta = '{"ordenes":[';
$respuesta .= ']';
$respuesta .= '}';

if (isset($result)) {
    $respuesta = '{"ordenes":[';
    $ordenes=json_decode($result,true);
    $first = true;
    $coma = "";
    foreach ($ordenes["orders"] as $lista => $orden) {
        if ($first) {
            $first = false;
            $coma = "";
        } else {
            $coma = ",";
        }

        // Datos generales de la orden
        $respuesta .= $coma.'{';

        $respuesta .= '"id":'.$orden["id"].',';
        $respuesta .= '"orden":'. $orden["order_number"] .',';
        $respuesta .= '"fecha":"'.$orden["created_at"].'",';
        $respuesta .= '"forma_pago":"'.$orden["gateway"].'",';

        $respuesta .= '"subtotal":' . $orden["subtotal_price"] . ',';
        $respuesta .= '"impuesto":' . $orden["total_tax"] . ',';
        $respuesta .= '"total":' . $orden["total_price"] . ',';
        $respuesta .= '"peso_total_gramos":' . $orden["total_weight"] . ',';

        $respuesta .= '"status":"' . $orden["financial_status"] . '",';
        $respuesta .= '"status_despacho":"' . $orden["fulfillment_status"] . '",';
        $respuesta .= '"id_cliente":' . $orden["customer"]["id"] . ',';
        $respuesta .= '"nombre_cliente":"' . trim($orden["customer"]["first_name"])." ".trim($orden["customer"]["last_name"]) . '",';
        $respuesta .= '"cedula":"' . $orden["customer"]["note"] . '",';
        $respuesta .= '"telefono":"' . $orden["customer"]["phone"] . '",';
        $respuesta .= '"email":"' . $orden["customer"]["email"] . '",';

        // Detalle de la orden (productos pedidos)
        $respuesta .= '"detalle":[';
        $line_items = $orden["line_items"];
        $firs2 = true;
        $com2 = "";
        foreach ($line_items as $arreglo => $linea) {
            if ($firs2) {
                $firs2 = false;
                $com2 = "";
            } else {
                $com2 = ",";
            }
            $respuesta .= $com2.'{';

            $respuesta .= '"id_detalle":' . $linea["id"] . ',';
            $id_producto = ($linea["product_id"]<>"") ? $linea["product_id"] : 0;
            $respuesta .= '"id_producto":' . $id_producto . ',';
            $respuesta .= '"id_variante":' . $linea["variant_id"] . ',';
            $respuesta .= '"nombre_shopify":"' . $linea["title"] . '",';
            $respuesta .= '"sku_shopify":"' . $linea["sku"] . '",';
            $respuesta .= '"cantidad_ordenada":' . $linea["quantity"] . ',';
            $respuesta .= '"precio_unitario":' . $linea["price"] . ',';
            $respuesta .= '"status_despacho":"' . $linea["fulfillment_status"] . '",';
            $respuesta .= '"pendiente_despacho":' . $linea["fulfillable_quantity"] . ',';
            $respuesta .= '"peso_unitario_gramos":' . $linea["grams"];

            $respuesta .= '}';
        }
        $respuesta .= '],';


        // Despachos
        $respuesta .= '"despachos":[';
        $fulfillments = $orden["fulfillments"];
        $firs2 = true;
        $com2 = "";
        foreach ($fulfillments as $arreglo => $despachos) {
            if ($firs2) {
                $firs2 = false;
                $com2 = "";
            } else {
                $com2 = ",";
            }
            $respuesta .= $com2.'{';

            $respuesta .= '"id_despacho":' . $despachos["id"] . ',';
            $respuesta .= '"id_almacen":' . $despachos["location_id"] . ',';
            // Detalle de los despachos
            $respuesta .= '"detalle_despacho":[';
            $lineas = $despachos["line_items"];
            $firs3 = true;
            $com3 = "";
            foreach ($lineas as $arreglo => $det_despacho) {
                if ($firs3) {
                    $firs3 = false;
                    $com3 = "";
                } else {
                    $com3 = ",";
                }
                $respuesta .= $com3.'{';
                $respuesta .= '"id_det_despacho":' . $det_despacho["id"] . ',';
                $id_producto = ($det_despacho["product_id"]<>"") ? $det_despacho["product_id"] : 0;
                $respuesta .= '"id_producto":' . $id_producto . ',';
                $respuesta .= '"id_variante":' . $det_despacho["variant_id"] . ',';
                $respuesta .= '"nombre_shopify":"' . $det_despacho["title"] . '",';
                $respuesta .= '"sku_shopify":"' . $det_despacho["sku"] . '",';
                $respuesta .= '"cantidad_ordenada":' . $det_despacho["quantity"] . ',';
                $respuesta .= '"precio_unitario":' . $det_despacho["price"] . ',';
                $respuesta .= '"status_despacho":"' . $det_despacho["fulfillment_status"] . '",';
                $respuesta .= '"pendiente_despacho":' . $det_despacho["fulfillable_quantity"] . ',';
                $respuesta .= '"peso_unitario_gramos":' . $det_despacho["grams"];
                $respuesta .= '}';
            }
            $respuesta .= '],';
            // Números de guía            
            $respuesta .= '"numeros_guia":[';
            $firs3 = true;
            $com3 = "";
            foreach ($despachos["tracking_numbers"] as $arreglo => $guia) {
                if ($firs3) {
                    $firs3 = false;
                    $com3 = "";
                } else {
                    $com3 = ",";
                }
                $respuesta .= $com3.'"'.$guia.'"';
            }
            $respuesta .= ']';
            $respuesta .= '}';
        }
        $respuesta .= '],';

        // Buscar transacciones
        $url = $urlBuscarTransaccion.trim($orden["id"]).'/transactions.json';

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url );
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
        curl_setopt($ch,CURLOPT_HEADER, false);

        $result=curl_exec($ch);
        curl_close($ch);

        $registros=json_decode($result,true);
        // Despachos
        $respuesta .= '"transacciones":[';
        $transacciones = $registros["transactions"];
        $firs2 = true;
        $com2 = "";
        foreach ($transacciones as $arreglo => $transaccion) {
            if ($firs2) {
                $firs2 = false;
                $com2 = "";
            } else {
                $com2 = ",";
            }
            $respuesta .= $com2.'{';

            $respuesta .= '"id_transaccion":' . $transaccion["id"] . ',';
            $respuesta .= '"tipo":"' . $transaccion["kind"] . '",';
            $respuesta .= '"forma_pago":"' . $transaccion["gateway"] . '",';
            $respuesta .= '"fecha_transaccion":"' . $transaccion["created_at"] . '",';
            $respuesta .= '"monto_transaccion":' . $transaccion["amount"] . ',';
            $respuesta .= '"status":"' . $transaccion["status"] . '"';

            $respuesta .= '}';
        }
        $respuesta .= '],';

        // Buscar adicionales
        $url = $urlOrdenMetafields.trim($orden["id"]).'/metafields.json';

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url );
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
        curl_setopt($ch,CURLOPT_HEADER, false);

        $result=curl_exec($ch);
        curl_close($ch);

        $registros=json_decode($result,true);
        // Despachos
        $respuesta .= '"adicionales":[';
        $metafields = $registros["metafields"];
        $firs2 = true;
        $com2 = "";
        foreach ($metafields as $arreglo => $metafield) {
            if ($firs2) {
                $firs2 = false;
                $com2 = "";
            } else {
                $com2 = ",";
            }
            $respuesta .= $com2.'{';

            $respuesta .= '"id_adicional":' . $metafield["id"] . ',';
            $respuesta .= '"grupo":"' . $metafield["namespace"] . '",';
            $respuesta .= '"clave":"' . $metafield["key"] . '",';
            $respuesta .= '"value":"' . $metafield["value"] . '"';

            $respuesta .= '}';
        }
        $respuesta .= ']';

/////////////////////////////////////////////////////////////////////////////////////
        $respuesta .= '}';
    }
    $respuesta .= ']';
    $respuesta .= '}';
}

echo $respuesta;
?>
