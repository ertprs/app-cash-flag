<?php
header('Content-Type: application/json');
include_once("../../_config/conexion.php");
set_time_limit(3600);

// Buscar transacción
$registros = json_decode( $_POST["registros"], true );
$hoy = date('Y-m-d');

$respuesta = '{';
$respuesta .= '"exito":"SI",';
$respuesta .= '"mensaje":"' . utf8_encode('Exito') . '",';

$x1 = "";
$x2 = "";
$x3 = "";
$x4 = "";
$x5 = "";
foreach ($registros as $key => $value) {
  $query  = 'SELECT * FROM compras_productos WHERE id1="'.$value["id1"].'"';
  $result = mysqli_query($link, $query);
  if($row = mysqli_fetch_array($result)) {
    $xcodigo = $row["id"];
    $x1 .= $xcodigo.'-';

    $query  = 'SELECT * FROM compras_listaprecios WHERE proveedor="'.$_POST["proveedor"].'" AND idprod="'.$xcodigo.'"';
    $result = mysqli_query($link, $query);
    if($row = mysqli_fetch_array($result)) {
      $id = $row["id"];
      $query = 'UPDATE compras_listas SET precio='.$value["precio"].', fecha="'.$hoy.'"';
      $result = mysqli_query($link, $query);
    } else {
      $query  = 'INSERT INTO compras_listaprecios (proveedor, idprod, precio, fecha) VALUES ';
      $query .= '("'.$_POST["proveedor"].'", '.$xcodigo.', '.$value["precio"].',"'.$hoy.'")';
      $result = mysqli_query($link, $query);
    }
  } else {
    $query  = 'SELECT * FROM compras_productos WHERE id1="'.$value["id2"].'"';
    $result = mysqli_query($link, $query);
    if($row = mysqli_fetch_array($result)) {
      $xcodigo = $row["id"];
      $x2 .= $xcodigo.'-';

      $query  = 'SELECT * FROM compras_listaprecios WHERE proveedor="'.$_POST["proveedor"].'" AND idprod="'.$xcodigo.'"';
      $result = mysqli_query($link, $query);
      if($row = mysqli_fetch_array($result)) {
        $id = $row["id"];
        $query = 'UPDATE compras_listas SET precio='.$value["precio"].', fecha="'.$hoy.'"';
        $result = mysqli_query($link, $query);
      } else {
        $query  = 'INSERT INTO compras_listaprecios (proveedor, idprod, precio, fecha) VALUES ';
        $query .= '("'.$_POST["proveedor"].'", '.$xcodigo.', '.$value["precio"].',"'.$hoy.'")';
        $result = mysqli_query($link, $query);
      }
    } else {
      $query  = 'SELECT * FROM compras_productos WHERE id1="'.$value["id3"].'"';
      $result = mysqli_query($link, $query);
      if($row = mysqli_fetch_array($result)) {
        $xcodigo = $row["id"];
        $x3 .= $xcodigo.'-';

        $query  = 'SELECT * FROM compras_listaprecios WHERE proveedor="'.$_POST["proveedor"].'" AND idprod="'.$xcodigo.'"';
        $result = mysqli_query($link, $query);
        if($row = mysqli_fetch_array($result)) {
          $id = $row["id"];
          $query = 'UPDATE compras_listas SET precio='.$value["precio"].', fecha="'.$hoy.'"';
          $result = mysqli_query($link, $query);
        } else {
          $query  = 'INSERT INTO compras_listaprecios (proveedor, idprod, precio, fecha) VALUES ';
          $query .= '("'.$_POST["proveedor"].'", '.$xcodigo.', '.$value["precio"].',"'.$hoy.'")';
          $result = mysqli_query($link, $query);
        }
      } else {
        $query  = 'SELECT * FROM compras_productos WHERE id1="'.$value["id4"].'"';
        $result = mysqli_query($link, $query);
        if($row = mysqli_fetch_array($result)) {
          $xcodigo = $row["id"];
          $x4 .= $xcodigo.'-';

          $query  = 'SELECT * FROM compras_listaprecios WHERE proveedor="'.$_POST["proveedor"].'" AND idprod="'.$xcodigo.'"';
          $result = mysqli_query($link, $query);
          if($row = mysqli_fetch_array($result)) {
            $id = $row["id"];
            $query = 'UPDATE compras_listas SET precio='.$value["precio"].', fecha="'.$hoy.'"';
            $result = mysqli_query($link, $query);
          } else {
            $query  = 'INSERT INTO compras_listaprecios (proveedor, idprod, precio, fecha) VALUES ';
            $query .= '("'.$_POST["proveedor"].'", '.$xcodigo.', '.$value["precio"].',"'.$hoy.'")';
            $result = mysqli_query($link, $query);
          }
        } else {
          $query = "select auto_increment from information_schema.tables where table_schema='clubdeconsumidores' and table_name='compras_productos'";
          // $query = "select auto_increment from information_schema.tables where table_schema='clubdeconsumidores' and table_name='compras_productos'";
          $result = mysqli_query($link,$query);
          if($row = mysqli_fetch_array($result)) {
              $idprod = $row["auto_increment"];
          } else {
              $idprod = 0;
          }
          $x5 .= $idprod.'-';

          $query  = 'INSERT INTO compras_productos (id1, id2, id3, id4, descripcion) VALUES ';
          $query .= '("'.$value["id1"].'","'.$value["id2"].'","'.$value["id3"].'","'.$value["id4"].'","'.$value["descripcion"].'")';
          $result = mysqli_query($link, $query);

          $query  = 'INSERT INTO compras_listaprecios (proveedor, idprod, precio, fecha) VALUES ';
          $query .= '("'.$_POST["proveedor"].'", '.$idprod.', '.$value["precio"].',"'.$hoy.'")';
          $result = mysqli_query($link, $query);
        }
      }
    }
  }
}
$respuesta .= '"registros1":["'.$x1.'"],';
$respuesta .= '"registros2":["'.$x2.'"],';
$respuesta .= '"registros3":["'.$x3.'"],';
$respuesta .= '"registros4":["'.$x4.'"],';
$respuesta .= '"registros5":["'.$x5;
$respuesta .= '"]';
$respuesta .= '}';

echo $respuesta;
?>
