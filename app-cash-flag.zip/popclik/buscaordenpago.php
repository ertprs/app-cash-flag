<?php
include_once("../_config/configShopify.php");

$url = $urlUnaOrden.$_GET["orden"].".json";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
curl_setopt($ch,CURLOPT_HEADER, false);

$result=curl_exec($ch);

$saldo = 0.00;
curl_close($ch);
if (isset($result)) {
    $url = $urlBuscarTransaccion.trim($_GET["orden"]).'/transactions.json';
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url );
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional params
    curl_setopt($ch,CURLOPT_HEADER, false);

    $resul2=curl_exec($ch);
    curl_close($ch);

    $transaccion=json_decode($resul2,true);

    $parent_id = $transaccion["transactions"][0]["id"];
    $monto = $transaccion["transactions"][0]["amount"];
    $saldo = $transaccion["transactions"][0]["amount"];
    foreach ($transaccion["transactions"] as $key => $value) {
        if ($value["id"]!=$parent_id) {
            $saldo -= $value["amount"];
        }
    }
}

// echo $result;

$respuesta = '{"exito":"NO",';
$respuesta .= '"orden":{';
$respuesta .= '"id":0,';
$respuesta .= '"numero":0,';
$respuesta .= '"nombres":"",';
$respuesta .= '"email":"",';
$respuesta .= '"monto":0,';
$respuesta .= '"saldo":0}';
$respuesta .= '}';
if (isset($result)) {
    $orden=json_decode($result,true);
    $respuesta = '{"exito":"SI",';
    $respuesta .= '"orden":{';
    $respuesta .= '"id":'.$orden["order"]["id"].',';
    $respuesta .= '"numero":'. $orden["order"]["order_number"] .',';
    $respuesta .= '"nombres":"';
        $respuesta .= trim($orden["order"]["customer"]["first_name"]).' ';
        $respuesta .= trim($orden["order"]["customer"]["last_name"]) . '",';
    $respuesta .= '"email":"'. $orden["order"]["email"] .'",';
    $respuesta .= '"monto":'. $monto .',';
    // $respuesta .= '"saldo":'. $orden["order"]["total_price"] .'}';
    $respuesta .= '"saldo":'. $saldo .'}';
    $respuesta .= '}';
}
echo $respuesta;
?>
