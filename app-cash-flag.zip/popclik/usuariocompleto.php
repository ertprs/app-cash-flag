<?php 
header('Content-Type: application/json');
include_once("../_config/conexion.php");

$quer0 = "select * from puntosderecaudacion_usuarios where id=".$_GET["id"];
$resul0 = mysqli_query($link,$quer0);
if ($ro0 = mysqli_fetch_array($resul0)) {
    $respuesta  = '{';
    $respuesta .= '"exito":"SI",';
    $respuesta .= '"id":'        . $ro0["id"]       . ',';
    $respuesta .= '"usuario":"'  . $ro0["usuario"]  . '",';
    $respuesta .= '"email":"'    . $ro0["email"]    . '",';
    $respuesta .= '"pregunta":"' . $ro0["pregunta"] . '",';
    $respuesta .= '"hashp":"'    . $ro0["hashp"]    . '",';
    $respuesta .= '"hashr":"'    . $ro0["hashr"]    . '",';
    $respuesta .= '"status":'    . $ro0["status"];
    $respuesta .= '}';
} else {
    $respuesta = '{"exito":"NO"}';
}
echo $respuesta;
?>
