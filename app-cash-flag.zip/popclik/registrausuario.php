<?php 
header('Content-Type: application/json');
include_once("../_config/conexion.php");

if ($_POST["id"]=="New") {
    $hashp = hash("sha256",$_POST["pass"]);
    $hashr = hash("sha256",$_POST["resp"]);

    $query  = 'INSERT INTO puntosderecaudacion_usuarios (idpunto, email, usuario, pregunta, hashp, ';
    $query .= 'hashr, status) VALUES ('.$_POST["idpunto"].',"'.$_POST["email"].'","'.$_POST["usuario"].'",';
    $query .= '"'.$_POST["preg"].'","'.$hashp.'","'.$hashr.'",'.$_POST["status"].')';
    $result = mysqli_query($link, $query);

    $respuesta = '{"exito":"SI",';
    $respuesta .= '"mensaje":"Registro exitoso"}';
} else {
    $query  = 'UPDATE puntosderecaudacion_usuarios SET email="'.$_POST["email"].'", ';
    $query .= 'usuario="'.$_POST["usuario"].'", status='.$_POST["status"].' WHERE id='.$_POST["id"];
    $result = mysqli_query($link, $query);

    $respuesta = '{"exito":"SI",';
    $respuesta .= '"mensaje":"Registro exitoso"}';
}
echo $respuesta;
?>
