<?php 
header('Content-Type: application/json');
include_once("../_config/conexion.php");

$query = 'SELECT * FROM puntosderecaudacion where email="'.$_GET["email"].'"';
$result = mysqli_query($link, $query);
$id = 0;
if ($row = mysqli_fetch_array($result)) {
    $id = $row['id'];
    $respuesta = '{"exito":"SI",';
    $respuesta .= '"id":'.$id.',';
    $respuesta .= '"hashp":"'. $row["hashp"] .'",';
    $respuesta .= '"pregunta":"' . utf8_encode($row["pregunta"]) . '",';
    $respuesta .= '"hashr":"' . $row["hashr"] . '",';
    $respuesta .= '"nombrepunto":"' . utf8_encode($row["nombre"]) . '",';
    $respuesta .= '"operador":"' . utf8_encode($row["usuario"]) . '",';
    $respuesta .= '"lineadecredito":' . $row["lineadecredito"] . ',';
    $respuesta .= '"saldolineadecredito":' . $row["saldolineadecredito"] . ',';
    $respuesta .= '"diasdecredito":' . $row["diasdecredito"] . ',';
    $respuesta .= '"proximopago":"' . $row["proximopago"] . '",';
    $respuesta .= '"usuario":"supervisor",';
    $respuesta .= '"status":1,';
    $respuesta .= '"mensaje":"exito"}';
} else {
    $query = 'SELECT puntosderecaudacion_usuarios.id, puntosderecaudacion_usuarios.email, puntosderecaudacion_usuarios.usuario, puntosderecaudacion_usuarios.pregunta, puntosderecaudacion_usuarios.hashp, puntosderecaudacion_usuarios.hashr, puntosderecaudacion.nombre, puntosderecaudacion.lineadecredito, puntosderecaudacion.saldolineadecredito, puntosderecaudacion.diasdecredito, puntosderecaudacion.proximopago, puntosderecaudacion_usuarios.status FROM puntosderecaudacion_usuarios left outer join puntosderecaudacion on puntosderecaudacion_usuarios.idpunto=puntosderecaudacion.id where puntosderecaudacion_usuarios.email="'.$_GET["email"].'"';
    $result = mysqli_query($link, $query);
    $id = 0;
    if ($row = mysqli_fetch_array($result)) {
        $id = $row['id'];
        $respuesta = '{"exito":"SI",';
        $respuesta .= '"id":'.$id.',';
        $respuesta .= '"hashp":"'. $row["hashp"] .'",';
        $respuesta .= '"pregunta":"' . utf8_encode($row["pregunta"]) . '",';
        $respuesta .= '"hashr":"' . $row["hashr"] . '",';
        $respuesta .= '"nombrepunto":"' . utf8_encode($row["nombre"]) . '",';
        $respuesta .= '"operador":"' . utf8_encode($row["usuario"]) . '",';
        $respuesta .= '"lineadecredito":' . $row["lineadecredito"] . ',';
        $respuesta .= '"saldolineadecredito":' . $row["saldolineadecredito"] . ',';
        $respuesta .= '"diasdecredito":' . $row["diasdecredito"] . ',';
        $respuesta .= '"proximopago":"' . $row["proximopago"] . '",';
        $respuesta .= '"usuario":"operador",';
        $respuesta .= '"status":'.$row["status"].',';
        $respuesta .= '"mensaje":"exito"}';
    } else {
        $respuesta = '{"exito":"NO",';
        $respuesta .= '"id":'.$id.',';
        $respuesta .= '"hashp":"",';
        $respuesta .= '"pregunta":"",';
        $respuesta .= '"hashr":"",';
        $respuesta .= '"nombrepunto":"",';
        $respuesta .= '"operador":"",';
        $respuesta .= '"lineadecredito":0.00,';
        $respuesta .= '"saldolineadecredito":0.00,';
        $respuesta .= '"diasdecredito":0,';
        $respuesta .= '"proximopago":"2020-01-01",';
        $respuesta .= '"usuario":"operador",';
        $respuesta .= '"mensaje":"correo no registrado"}';
    }
}
echo $respuesta;
?>
