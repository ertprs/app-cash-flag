<?php 
header('Content-Type: application/json');
include_once("../_config/conexion.php");

if ($_POST["tipousuario"]=="supervisor") {
    $query  = 'UPDATE puntosderecaudacion SET hashp="'.$_POST["hashp"].'" ';
    $query .= 'WHERE email="'.$_POST["email"].'"';
	if($result = mysqli_query($link, $query)) {
		$respuesta = '{"exito":"SI",';
		$respuesta .= '"mensaje":"Registro exitoso"}';
	} else {
		$respuesta = '{"exito":"NO",';
		$respuesta .= '"mensaje":"Falló el registro."}';
	}
} else {
    $query  = 'UPDATE puntosderecaudacion_usuarios SET hashp="'.$_POST["hashp"].'" ';
    $query .= 'WHERE email="'.$_POST["email"].'"';
	if($result = mysqli_query($link, $query)) {
		$respuesta = '{"exito":"SI",';
		$respuesta .= '"mensaje":"Registro exitoso"}';
	} else {
		$respuesta = '{"exito":"NO",';
		$respuesta .= '"mensaje":"Falló el registro."}';
	}
}
echo $respuesta;
?>
