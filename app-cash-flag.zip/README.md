<p align="center"><a href="https://www.cash-flag.com/" target="_blank">
    <img src="https://www.cash-flag.com/img/logoclub.png" width="20%">
</a></p>

[Cash Flag][1] es una plataforma transaccional para integrar servicios B2B y B2C que busca proveer a los comercios afiliados de una herramienta para incrementar el Life Time Value de su cartera de clientes ofreciendo a sus consumidores beneficios por ser compradores frecuentes, así como un medio de pago alternativo y otros servicios que faciliten las operaciones comerciales.

Configuración
-------------

### Base de datos

Copiar el archivo **conexion-dist.php** en **conexion.php** y confirgurar con sus parametros de base de datos.

[1]: https://www.cash-flag.com/